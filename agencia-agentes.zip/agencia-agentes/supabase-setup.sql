-- TABELA: Fila de prospecção (nichos x cidades)
CREATE TABLE IF NOT EXISTS fila_prospeccao (
  id SERIAL PRIMARY KEY,
  nicho TEXT NOT NULL,
  cidade TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'SC',
  status TEXT NOT NULL DEFAULT 'pendente', -- pendente | processado
  processado_em TIMESTAMPTZ,
  total_encontrados INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TABELA: Leads encontrados
CREATE TABLE IF NOT EXISTS leads (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL,
  telefone TEXT,
  endereco TEXT,
  avaliacao NUMERIC,
  total_avaliacoes INT DEFAULT 0,
  nicho TEXT,
  cidade TEXT,
  estado TEXT,
  site_gerado BOOLEAN DEFAULT FALSE,
  site_url TEXT,
  site_vercel_id TEXT,
  status TEXT DEFAULT 'novo', -- novo | site_gerado | contatado | fechado | expirado
  criado_em TIMESTAMPTZ DEFAULT NOW(),
  expira_em TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '7 days')
);

-- ÍNDICES
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_site_gerado ON leads(site_gerado);
CREATE INDEX IF NOT EXISTS idx_fila_status ON fila_prospeccao(status);

-- POPULAR FILA com nichos e cidades iniciais
INSERT INTO fila_prospeccao (nicho, cidade, estado) VALUES
  ('barbearia', 'Palhoça', 'SC'),
  ('barbearia', 'São José', 'SC'),
  ('barbearia', 'Florianópolis', 'SC'),
  ('barbearia', 'Joinville', 'SC'),
  ('barbearia', 'Blumenau', 'SC'),
  ('pet shop', 'Palhoça', 'SC'),
  ('pet shop', 'São José', 'SC'),
  ('pet shop', 'Florianópolis', 'SC'),
  ('pet shop', 'Joinville', 'SC'),
  ('restaurante', 'Palhoça', 'SC'),
  ('restaurante', 'São José', 'SC'),
  ('restaurante', 'Florianópolis', 'SC'),
  ('clínica odontológica', 'Palhoça', 'SC'),
  ('clínica odontológica', 'São José', 'SC'),
  ('clínica odontológica', 'Florianópolis', 'SC'),
  ('academia', 'Palhoça', 'SC'),
  ('academia', 'São José', 'SC'),
  ('academia', 'Florianópolis', 'SC'),
  ('salão de beleza', 'Palhoça', 'SC'),
  ('salão de beleza', 'São José', 'SC'),
  ('salão de beleza', 'Florianópolis', 'SC'),
  ('mecânica', 'Palhoça', 'SC'),
  ('mecânica', 'São José', 'SC'),
  ('farmácia', 'Palhoça', 'SC'),
  ('farmácia', 'São José', 'SC'),
  ('lanchonete', 'Palhoça', 'SC'),
  ('lanchonete', 'São José', 'SC'),
  ('barbearia', 'Curitiba', 'PR'),
  ('barbearia', 'Londrina', 'PR'),
  ('barbearia', 'Maringá', 'PR'),
  ('pet shop', 'Curitiba', 'PR'),
  ('restaurante', 'Curitiba', 'PR'),
  ('barbearia', 'Porto Alegre', 'RS'),
  ('barbearia', 'Caxias do Sul', 'RS'),
  ('pet shop', 'Porto Alegre', 'RS'),
  ('barbearia', 'São Paulo', 'SP'),
  ('barbearia', 'Campinas', 'SP'),
  ('barbearia', 'Ribeirão Preto', 'SP'),
  ('pet shop', 'Campinas', 'SP'),
  ('restaurante', 'Campinas', 'SP')
ON CONFLICT DO NOTHING;

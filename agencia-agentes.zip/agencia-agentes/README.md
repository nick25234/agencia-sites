# Agência de Sites — Agentes Automatizados

Sistema de 3 agentes que rodam todo dia automaticamente:

1. **Agente 1** (08h) — Prospecta empresas sem site no Google Maps
2. **Agente 2** (09h) — Gera sites via Claude API e deploya no Vercel
3. **Agente 3** (10h) — Envia relatório por WhatsApp e Email

---

## Setup — Passo a Passo

### 1. Supabase — Criar as tabelas

Acesse seu projeto em supabase.com, vá em **SQL Editor** e execute o conteúdo de `supabase-setup.sql`.

### 2. GitHub — Criar o repositório

```bash
# No GitHub, crie um repositório chamado "agencia-agentes"
# Depois suba os arquivos:
git init
git add .
git commit -m "setup agentes"
git remote add origin https://github.com/SEU_USUARIO/agencia-agentes.git
git push -u origin main
```

### 3. GitHub Secrets — Configurar as variáveis

No repositório GitHub, vá em:
**Settings → Secrets and variables → Actions → New repository secret**

Adicione uma a uma:

| Secret | Valor |
|--------|-------|
| `SUPABASE_URL` | https://SEU_PROJETO.supabase.co |
| `SUPABASE_SECRET_KEY` | sb_secret_... |
| `GOOGLE_PLACES_API_KEY` | AIzaSy... |
| `CLAUDE_API_KEY` | sk-ant-... |
| `VERCEL_TOKEN` | vcp_... |
| `RESEND_API_KEY` | re_... |
| `CALLMEBOT_PHONE` | 5548988484698 (com 55+DDD) |
| `CALLMEBOT_APIKEY` | seu número do CallMeBot |
| `EMAIL_DESTINO` | nickolasmatthewsss@gmail.com |

### 4. Testar manualmente

No GitHub, vá em **Actions → Agentes Diários → Run workflow**

Selecione qual agente testar e clique em **Run workflow**.

---

## O que você recebe todo dia às 10h

**WhatsApp:**
```
📋 Agência de Sites — 09/06/2026
✅ 12 sites gerados hoje

1. Barbearia Alpha
📍 Palhoça — barbearia
📞 (48) 98431-0104
🌐 https://agencia-barbearia-alpha.vercel.app
...
```

**Email:** Tabela formatada com botão "Ver site" para cada lead.

---

## Fluxo completo

```
08h — Agente 1 busca 1 combinação da fila (nicho + cidade)
      → Filtra empresas sem site
      → Salva no Supabase

09h — Agente 2 pega leads novos do Supabase
      → Gera HTML via Claude API (Haiku — rápido e barato)
      → Deploya no Vercel via API
      → Salva link no Supabase
      → Limpa sites expirados (> 7 dias sem fechar)

10h — Agente 3 monta relatório do dia
      → Envia por WhatsApp (CallMeBot)
      → Envia por Email (Resend)
```

---

## Custos diários estimados

| Item | Custo |
|------|-------|
| Google Places API | ~$0.05/dia |
| Claude API (20 sites) | ~R$1.80/dia |
| Vercel | Gratuito |
| GitHub Actions | Gratuito |
| **Total** | **~R$2/dia** |

Com 3% de conversão em 20 leads = R$450/dia de receita.
